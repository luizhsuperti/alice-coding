# $PROJECT_NAME$
## Description
Your project goal and related teams
## Owners
- $PROJECT_AUTHOR$ $PROJECT_EMAIL$
## Setup & Deploy
```pip install .```

## Documentation
General explanation of use cases

## API
methods, classes, constants and objects