from carai.interfaces.model import Model

class RandomModel(Model):
    def __init__(self):
        pass

    def fit(self):
        pass

    def predict(self):
        pass

    def evaluate(self):
        pass
